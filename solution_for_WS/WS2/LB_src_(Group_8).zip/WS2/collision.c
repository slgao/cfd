#include "collision.h"
#include <math.h>
#include "computeCellValues.h"
#include "LBDefinitions.h"
#define Q 19

void computePostCollisionDistributions(double *currentCell, const double * const tau, const double *const feq){
  int i;
  double t;
  t= *tau;
  for(i = 0; i <=Q - 1; i++)
    {
      currentCell[i] = currentCell[i] - 1/t *(currentCell[i] - feq[i]);
    }
}

void doCollision(double *collideField, int *flagField,const double * const tau,int xlength){
  int i, l, cellnum;
  l = xlength + 2;
  cellnum = l * l * l;
  for(i = 0; i <= cellnum - 1; i++)
    {
      if (flagField[i] == 0)
	{
	  double *const  currentCell = &collideField[i * Q];
	  double density, velocity[3], feq[Q];
	  computeDensity (currentCell, &density);
	  computeVelocity (currentCell, &density, velocity);
	  computeFeq (&density, velocity, feq);
	  computePostCollisionDistributions (currentCell, tau, feq);
	}      
    }
}

