#include "initLB.h"
#include <math.h>
#include "LBDefinitions.h"
#include "helper.h"
#define Q 19

int readParameters(int *xlength, double *tau, double *velocityWall, int *timesteps, int *timestepsPerPlotting, int argc, char *argv[]){
  /* TODO */
  double v1,v2,v3;

  READ_INT( argv[1], *xlength );
  READ_DOUBLE( argv[1], *tau );

 
  READ_DOUBLE   ( argv[1], v1 );
  READ_DOUBLE   ( argv[1], v2 );
  READ_DOUBLE   ( argv[1], v3 );

  READ_INT   ( argv[1], *timesteps );
  READ_INT   ( argv[1], *timestepsPerPlotting );

  *velocityWall = v1;
  *(velocityWall+1) = v2;
  *(velocityWall+2) = v3;
  return 0;
}


void initialiseFields(double *collideField, double *streamField, int *flagField, int xlength){
  int i, x, y, z, ind, l, cellnum, fnum, layernum, mod;
  l = xlength + 2;
  layernum = l * l;
  cellnum=l * l * l;
  fnum=Q*cellnum;
  printf("debug in initialiseFields\n");

  /* initialise collideField and streamField */
  for(i=0;i<=fnum-1;i++)
    {
      mod=i % Q;
      collideField[i] = LATTICEWEIGHTS[mod];
      streamField[i] = LATTICEWEIGHTS[mod];
    }
  printf("debug position 1\n");
  /* initialise flagField */
  for(z = 0;z <= l - 1;z++)
    for(y = 0;y <= l - 1;y++)
      for(x = 0;x <= l - 1;x++)
	{
	  ind = z * layernum + y * l + x;
	  if (z == l - 1)
	    flagField[ind] = 2.0;
	  else if (z == 0||x == 0||x == l - 1|| y == 0||y == l - 1)
	    flagField[ind] = 1.0;
	  else 
	    flagField[ind] = 0.0;
	}
  printf("debug position 2\n");
  printf("flagField is %d\n", flagField[37]);
  printf("collideField is %f\n", collideField[37]);
}

