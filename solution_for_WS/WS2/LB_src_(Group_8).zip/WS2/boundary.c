#include "boundary.h"
#include "LBDefinitions.h"
#include "computeCellValues.h"
#include <math.h>
#define Q 19

void treatBoundary(double *collideField, int* flagField, const double * const wallVelocity, int xlength){
  int l, x, y, z, i, ind, nb_x, nb_y, nb_z, inv_i, nb_ind, layernum;
  l = xlength + 2;
  layernum = l * l;
  for(z = 1;z <= l - 2;z++)
    for(y = 1;y <= l - 2;y++)
      for(x = 1;x <= l - 2;x++)
	{
	  ind = z * layernum + y * l + x;
	  for(i = 0; i <= Q - 1;i++ )
		{
		  nb_x = x + LATTICEVELOCITIES[i][0]; 
		  nb_y = y + LATTICEVELOCITIES[i][1];
		  nb_z = z + LATTICEVELOCITIES[i][2];
		  inv_i = Q - i - 1;
		  nb_ind = nb_z * layernum + nb_y * l + nb_x;
		  if (flagField[nb_ind] == 1)
		    {
		      collideField[nb_ind * Q + inv_i] = collideField[ind * Q + i];
		    }
		  else if (flagField[nb_ind] == 2)
		    {
		      double dens, CU_wall;
		      double * const current = &collideField[ind * Q];
		      computeDensity(current, & dens);
		      CU_wall = LATTICEVELOCITIES[i][0] * wallVelocity[0] + LATTICEVELOCITIES[i][1] * wallVelocity[1]
			+ LATTICEVELOCITIES[i][2] * wallVelocity[2];
		      collideField[nb_ind * Q + inv_i] = collideField[ind * Q + i] + 2 * LATTICEWEIGHTS[i] * dens * CU_wall/(C_S * C_S);
		    }
		}
	}
}


