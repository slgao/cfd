#include "streaming.h"
#include <math.h>
#include "LBDefinitions.h"
#define Q 19

void doStreaming(double *collideField, double *streamField,int *flagField,int xlength){
  int x, y, z, ind, i, inv_i, nb_x, nb_y, nb_z, nb_ind, l, layernum;
  l = xlength + 2;
  layernum = l * l;
  for(z = 0;z <= l - 1;z++)
     for(y = 0;y <= l - 1;y++)
       for(x = 0;x <= l - 1;x++)
	 {
	   ind = z * layernum + y * l + x;
	       for(i = 0; i <= Q - 1;i++ )
		 {
		   inv_i = Q - i - 1;
		   nb_x = x + LATTICEVELOCITIES[inv_i][0]; 
		   nb_y = y + LATTICEVELOCITIES[inv_i][1];
		   nb_z = z + LATTICEVELOCITIES[inv_i][2];	   
		   nb_ind =  nb_z * layernum + nb_y * l + nb_x;
		   if(flagField[ind]==0)/*check and find the fluid cells*/
		     {
		       streamField[ind * Q + i] = collideField[nb_ind * Q + i];/*neighbourcell is fluid*/
		       /* if(flagField[nb_ind]!=0) */
		       /* 	 streamField[nb_ind*Q+inv_i]=collideField[ind*Q+inv_i];  */
		     }
		 }
           
	 }
}
