#ifndef _MAIN_C_
#define _MAIN_C_

#include "collision.h"
#include "streaming.h"
#include "initLB.h"
#include "visualLB.h"
#include "boundary.h"
#include "helper.h"
#include "math.h"
#include <stdio.h>

#include "LBDefinitions.h"

#define Q 19


int main(int argc, char *argv[]){
  
  /* Variables */
  double  *streamField =NULL;
  double *collideField = NULL;
  double  tau,* wallVelocity;
  int   *flagField = NULL;
  int xlength, cellnum, timesteps, timePerPlotting, t, l;
  /* argv[1]= "cavity.dat"; */
  
  /* Reading parameters */
  wallVelocity = (double *)(malloc(3*sizeof(double)));
  readParameters(&xlength,&tau,wallVelocity,&timesteps,&timePerPlotting,argc,argv);
  l = xlength + 2;
  
/* Initializing the pointers */
  cellnum = l * l * l;
  
  collideField = (double *)malloc(Q* cellnum * sizeof(double));
  streamField = (double *)malloc(Q* cellnum * sizeof(double));
  flagField = (int *)malloc(cellnum * sizeof(int));
  
  /* Initializing the Fields */
  printf("Initializing the Fields \n");
  initialiseFields(collideField,streamField,flagField,xlength);
  
  
  
  
  /* Loop for time steps  */
  for(t=0;t<timesteps;t++){
    
    double *swap = NULL;
    /* STREAMING */
    doStreaming(collideField,streamField,flagField,xlength);
      
    /* Swapping the pointers of the streamField and collideField*/
    swap = collideField;
    collideField = streamField;
    streamField = swap;
    
    /* collision */
    printf("Doing Collision\n");
    doCollision(collideField,flagField,&tau,xlength);
    
    /* Treating the boundaries */
    printf("Treating the Boundaries \n");
    treatBoundary(collideField,flagField,wallVelocity,xlength);
    
    /* generate vtk file  */
    if(t % timePerPlotting == 0){
      printf("Writing output at time: %d \n", t);
      writeVtkOutput(collideField,flagField,*argv,t,xlength);
    }
    
  }
  free(streamField);
  free(collideField);
  free(flagField);
  return 0;
}

#endif

