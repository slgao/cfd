#include "computeCellValues.h"
#include <math.h>
#include "LBDefinitions.h"
#define Q 19

void computeDensity(const double * const currentCell, double *density){
  int i;
  double sum;
  sum = 0.0;
  for (i = 0;i <= Q - 1;i++ )
    {
      sum = sum + currentCell[i];
    }
  *density = sum;
}

void computeVelocity(const double * const currentCell, const double * const density, double *velocity){
  int i;
  double dens;
  dens = *density;
  velocity[0] = 0.0;  velocity[1] = 0.0;  velocity[2] = 0.0;
  for (i = 0;i <= Q - 1; i++)
    {
      velocity[0] = velocity[0] + currentCell[i] * LATTICEVELOCITIES[i][0];
      velocity[1] = velocity[1] + currentCell[i] * LATTICEVELOCITIES[i][1];
      velocity[2] = velocity[2] + currentCell[i] * LATTICEVELOCITIES[i][2];
    }
  velocity[0] = velocity[0]/dens;
  velocity[1] = velocity[1]/dens;
  velocity[2] = velocity[2]/dens;

  /* velocity[0] = (- currentCell[1] + currentCell[3] - currentCell[5] + currentCell[7] 
     - currentCell[8] + currentCell[10] - currentCell[11] + currentCell[13] - currentCell[15] + currentCell[17]) / dens;
     velocity[1] = (- currentCell[0] + currentCell[4] - currentCell[5] - currentCell[6] 
     - currentCell[7] + currentCell[11] - currentCell[12] + currentCell[13] - currentCell[14] + currentCell[18]) / dens;
     velocity[2] = (- currentCell[0] - currentCell[1] - currentCell[2] - currentCell[3] 
     - currentCell[4] + currentCell[14] + currentCell[15] + currentCell[16] + currentCell[17] + currentCell[18]) / dens;*/
}

void computeFeq(const double * const density, const double * const velocity, double *feq){
  int i;
  double  CU[Q], dens, UU;
  dens = *density;
  UU = velocity[0] * velocity[0] + velocity[1] * velocity[1] + velocity[2] * velocity[2];

  for(i = 0; i <= Q-1; i++)
    {
      CU[i] = LATTICEVELOCITIES[i][0] * velocity[0] + LATTICEVELOCITIES[i][1] * velocity[1] + LATTICEVELOCITIES[i][2] * velocity[2];
      feq[i] = LATTICEWEIGHTS[i] * dens * (1 + CU[i]/(C_S * C_S) + (CU[i] * CU[i])/(2 * (C_S * C_S * C_S * C_S)) - UU/(2 * C_S * C_S));
    }
}

