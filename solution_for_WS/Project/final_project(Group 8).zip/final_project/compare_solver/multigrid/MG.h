double ** Calculate_res(
   int **Flag,
   double **RS,
   double **P,
   double dx,
   double dy,
   int Nx,
   int Ny	   
			);

double ** restriction(
    int Nx,
    int Ny,		      
    double **res
		      );

double ** interpolation(
    int Nx,
    int Ny,
    double **e
			
			);

double ** V_cycle(
     double **P,
     double **RS,
     int Nxf,
     int Nyf,
     double omg,
     double dx,
     double dy,
     int **Flag,
     char *problem
    	  
		  );
