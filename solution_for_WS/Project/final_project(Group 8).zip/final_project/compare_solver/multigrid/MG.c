#include "MG.h"
#include "helper.h"
#include "sor.h"

double ** Calculate_res(
   int **Flag,
   double **RS,
   double **P,
   double dx,
   double dy,
   int Nx,
   int Ny	   
		   )
{

/* compute the residual */
  double **res;
  int i,j;
  res = matrix(1,Nx,1,Ny); 
  for(i = 1; i <= Nx; i++) {
    for(j = 1; j <= Ny; j++) {
      if((Flag[i][j]&0x10)!=0)
	{
	  res[i][j] =RS[i][j] - (P[i+1][j]-2.0*P[i][j]+P[i-1][j])/(dx*dx) + ( P[i][j+1]-2.0*P[i][j]+P[i][j-1])/(dy*dy);
	}
    }
  }
  return res;
}

double ** restriction(
    int Nx,
    int Ny,		      
    double **res
		      )
{
  double **r;
  int i,j;
  r = matrix(1,Nx,1,Ny);
  for(j=1;j<=Ny;j++)
    for(i=1;i<=Nx;i++)
      r[i][j] = res[2*i][2*j];
  return r;
}

double ** interpolation(
    int Nx,
    int Ny,
    double **e
			
)
{
  int i,j;
  int a=(Nx-1)/2+2;
  int b=(Ny-1)/2+2;
  double **econ, **e1, **e2;
  econ = matrix(1,a,1,b);
  init_matrix(econ,1,a,1,b,0);
  for (j=2;j<=b-1;j++)
    for (i=2;i<=a-1;i++)
      econ[i][j] = e[i-1][j-1];
  e1 = matrix(1,Nx+1,1,Ny+1);
  init_matrix(e1,1,Nx+1,1,Ny+1,0);
  for (j=1;j<=b-1;j++)
    for (i=1;i<=a-1;i++)
      {
	e1[2*i-1][2*j-1] = 1/4*(econ[i][j]+econ[i][j+1]+econ[i+1][j]+econ[i+1][j+1]);
	e1[2*i-1][2*j] = 1/2*(econ[i][j+1]+econ[i+1][j+1]);
	e1[2*i][2*j-1] = 1/2*(econ[i+1][j]+econ[i+1][j+1]);
      }
  e2 = matrix(1,Nx,1,Ny);
  init_matrix(e2,1,Nx,1,Ny,0);
  for (j=1;j<=Ny;j++)
    for (i=1;i<=Nx;i++)
      e2[i][j] = e1[i][j];
  for (j=1;j<=b-2;j++)
    for (i=1;i<=a-2;i++)
      e2[2*i][2*j] = e[i][j];
  return e2;
  
}

double ** V_cycle(
     double **P,
     double **RS,
     int Nxf,
     int Nyf,
     double omg,
     double dx,
     double dy,
     int **Flag,
     char *problem
    	  
){
  int Nxc,Nyc;
  int i,j;
  double **Pf,**rf,**rc,**ec1,**ec2,**ef;
  Nxc=(Nxf-1)/2;Nyc=(Nyf-1)/2;
  /* printf("in the vcycle\n"); */
  /* Pf = matrix(1,Nxf,1,Nyf); */
  /* rf =matrix(1,Nxf,1,Nyf); */
  /* rc = matrix(1,Nxc,1,Nyc); */
  /* rc = matrix(1,Nxc,1,Nyc); */
  ec1 = matrix(0,Nxc+1,0,Nyc+1);
  init_matrix(ec1,0,Nxc+1,0,Nyc+1,0);
  /* ec2 = matrix(1,Nxc,1,Nyc); */
  /* ef =matrix(1,Nxf,1,Nyf); */
  /* printf("P5,5 is :::%f\n",P[5][5]); */
  /* for (i=1;i<=50;i++) */
  /*   { */
  Pf=sor(omg,dx,dy,Nxf,Nyf,P,RS,Flag,problem);
  
  /* printf("Pf5,5 is :::%f\n",Pf[5][5]); */
  /* } */
  rf=Calculate_res(Flag,RS,P,dx,dy,Nxf,Nyf);

  if (Nxf>3){
    rc=restriction(Nxc,Nyc,rf);
    ec2=V_cycle(ec1,rc,Nxc,Nyc,omg,dx,dy,Flag,problem);
    ef=interpolation(Nxf,Nyf,ec2);
    for (i=1;i<=Nxf;i++)
      for (j=1;j<=Nyf;j++)
	Pf[i][j]=Pf[i][j]+ef[i][j];
  }
  Pf=sor(omg,dx,dy,Nxf,Nyf,Pf,RS,Flag,problem);

  return Pf;
  
}
