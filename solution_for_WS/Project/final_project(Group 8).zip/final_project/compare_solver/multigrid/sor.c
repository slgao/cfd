#include "sor.h"
#include <math.h>
#include "Definitions.h"
#include "string.h"
#include "stdio.h"
#include "MG.h"
#include "helper.h"

double** sor(
  double omg,
  double dx,
  double dy,
  int    imax,
  int    jmax,
  double **PP,
  double **RS,
  int **Flag,
  char *problem
  
) {
  int i,j,k;
  double **P;
  double coeff = omg/(2.0*(1.0/(dx*dx)+1.0/(dy*dy)));
  P= matrix(0,imax+1,0,jmax+1);
  P=PP;
  /* SOR iteration */
  for (k=1;k<=3;k++){
  for(i = 1; i <= imax; i++) {
    for(j = 1; j<=jmax; j++) {
      if((Flag[i][j]&0x10)!=0)
	{
	  P[i][j] = (1.0-omg)*P[i][j]
	    + coeff*(( P[i+1][j]+P[i-1][j])/(dx*dx) + ( P[i][j+1]+P[i][j-1])/(dy*dy) - RS[i][j]);

	}
    }
  }


 
  /* set top and bottom boundary values */
  for(i = 1; i <= imax; i++) {
    P[i][0] = P[i][1];
    P[i][jmax+1] = P[i][jmax];
  }

 if(strcmp(problem,"test.dat")==0)
   {
     for(j = 1; j <= jmax; j++)
       {
 	 P[0][j] = P[1][j];
 	 P[imax+1][j] = P[imax][j];
       }
   }
 /* inner boundary */
  for (i=1;i<imax+1;i++)
    for (j=1;j<jmax+1;j++)
      {
	if((Flag[i][j] & 0x10)==0)
	  {
	    switch(Flag[i][j])
	      {
	      case B_N:   
		P[i][j]=P[i][j+1];
		break;
	      case B_O:   
		P[i][j]=P[i+1][j];
		break;
	      case B_S:   
		P[i][j]=P[i][j-1];
		break;
	      case B_W:   
		P[i][j]=P[i-1][j];
		break;
	      case B_NO:  
		P[i][j]=(P[i][j+1]+P[i+1][j])/2;
		break;
	      case B_SO:  
		P[i][j]=(P[i+1][j]+P[i][j-1])/2;
		break;
	      case B_SW:  
		P[i][j]=(P[i-1][j]+P[i][j-1])/2;
		break;
	      case B_NW:  
		P[i][j]=(P[i][j+1]+P[i-1][j])/2;
		break;
	      default:
	      /* 	printf("forbidden boundary cells exit!\n"); */
	      	break;
	      }
	  }
      }
  }
  return P;
}

