Project <energy transportation and optimization of the solvers>
Group 8 ---- Shulin Gao, Teng Wang, Andrea Tagliabue

Here in this folder, we have two energy transport scenarios and one optimization solver scenario.

1----In the folder house_aircond(top view of the room), we simulated the temperature change of different rooms in a 
office building when the warm air conditioner blow in different positions. (Please use 
test.dat file to run all the cases and it will use the corresponding pgm file automatically.) 
Videos are attached to show the cases.

2----In the folder room_mainview(side view of the room), we simulated the temperature change between a bedroom and a kitchen, 
when kitchen has some heating source and there is an cooling air conditioner in the bedroom, corridor,
or kitchen. Videos are attached to show the cases.

3----In the folder compare_solver, we implemented multigrid solver (MG.c) and compared the performance to sor solver.
We set t_end(in test.dat file) to be 1 in our case, you can try different values (e.g 2, 3, 4, 5), and run the different solver 
case, the multigrid solver will complete the task much quickly than sor solver. Some videos are attached to compare 
the results of the two solvers.
